﻿using FilmMate.Data;
using FilmMate.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace TestProject1.Data
{
    [TestClass]
    public class FilmRespositoryTests
    {
        private FilmRepository repository;

        [TestInitialize]
        public void Setup()
        {
            repository = new FilmRepository();
        }

        [TestCleanup]
        public void Cleanup()
        {
            // Cleanup nije potreban jer repository koristi hardcoded file path
        }

        [TestMethod]
        public void GetAll_EmptyRepository_ShouldReturnEmptyList()
        {
            // Arrange & Act
            var result = repository.GetAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAll_AfterAddingFilms_ShouldReturnAllFilms()
        {
            // Arrange
            var film1 = new Film("Film 1", "Action", 8.5, 2020);
            var film2 = new Film("Film 2", "Drama", 7.5, 2021);
            repository.GetAll().Add(film1);
            repository.GetAll().Add(film2);

            // Act
            var result = repository.GetAll();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.Contains(film1));
            Assert.IsTrue(result.Contains(film2));
        }

        [TestMethod]
        public void Sacuvaj_WithFilms_ShouldCreateFile()
        {
            // Arrange
            var film = new Film("Test Film", "Comedy", 9.0, 2023);
            repository.GetAll().Add(film);

            // Act
            repository.Sacuvaj();

            // Assert - provjera da je fajl kreiran (ako repository koristi filePath)
            // Napomena: Ovo testira osnovnu funkcionalnost
            Assert.IsTrue(repository.GetAll().Count > 0);
        }

        // Data Driven Test: Testiranje dodavanja različitih filmova
        [DataRow("Film1", "Action", 8.5, 2020)]
        [DataRow("Film2", "Drama", 7.0, 2021)]
        [DataRow("Film3", "Comedy", 9.5, 2022)]
        [DataTestMethod]
        public void GetAll_AfterAddingFilm_ShouldContainFilm(
            string naziv, string kategorija, double ocjena, int godina)
        {
            // Arrange
            var film = new Film(naziv, kategorija, ocjena, godina);
            repository.GetAll().Add(film);

            // Act
            var result = repository.GetAll();

            // Assert
            Assert.IsTrue(result.Any(f => f.getNazivFilma() == naziv));
            var foundFilm = result.First(f => f.getNazivFilma() == naziv);
            Assert.AreEqual(kategorija, foundFilm.getKategorija());
            Assert.AreEqual(ocjena, foundFilm.getOcjena(), 0.1);
            Assert.AreEqual(godina, foundFilm.getGodina());
        }

        [TestMethod]
        public void Sacuvaj_EmptyList_ShouldHandleGracefully()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act & Assert - ne bi trebalo baciti izuzetak
            try
            {
                repository.Sacuvaj();
                Assert.IsTrue(true, "Sacuvaj treba da radi sa praznom listom");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Sacuvaj ne bi trebao baciti izuzetak sa praznom listom: {ex.Message}");
            }
        }

        [TestMethod]
        public void GetAll_AfterModification_ShouldReflectChanges()
        {
            // Arrange
            var film = new Film("Original", "Action", 5.0, 2020);
            repository.GetAll().Add(film);

            // Act
            film.setNaziv("Modified");
            var result = repository.GetAll();

            // Assert
            Assert.AreEqual("Modified", result[0].getNazivFilma());
        }
    }
}
