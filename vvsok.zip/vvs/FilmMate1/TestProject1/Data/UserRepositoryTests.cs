﻿using FilmMate.Data;
using FilmMate.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace TestProject1.Data
{
    [TestClass]
    public class UserRepositoryTests
    {
        private UserRepository repository;

        [TestInitialize]
        public void Setup()
        {
            repository = new UserRepository();
        }

        [TestCleanup]
        public void Cleanup()
        {
            // Cleanup nije potreban jer repository koristi hardcoded file path
        }

        [TestMethod]
        public void GetAll_EmptyRepository_ShouldReturnEmptyList()
        {
            // Arrange & Act
            var result = repository.GetAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAll_AfterAddingUsers_ShouldReturnAllUsers()
        {
            // Arrange
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("user1");
            gledalac.setLozinka("hash1");

            var admin = new Administrator();
            admin.setKorisnickoIme("admin1");
            admin.setLozinka("hash2");

            repository.GetAll().Add(gledalac);
            repository.GetAll().Add(admin);

            // Act
            var result = repository.GetAll();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.Contains(gledalac));
            Assert.IsTrue(result.Contains(admin));
        }

        [TestMethod]
        public void Sacuvaj_WithUsers_ShouldHandleCorrectly()
        {
            // Arrange
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("testuser");
            gledalac.setLozinka("testhash");
            repository.GetAll().Add(gledalac);

            // Act & Assert - ne bi trebalo baciti izuzetak
            try
            {
                repository.Sacuvaj();
                Assert.IsTrue(true, "Sacuvaj treba da radi sa korisnicima");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Sacuvaj ne bi trebao baciti izuzetak: {ex.Message}");
            }
        }

        // Data Driven Test: Testiranje dodavanja različitih tipova korisnika
        [DataRow("user1", "hash1", typeof(Administrator))]
        [DataRow("user2", "hash2", typeof(Gledalac))]
        [DataRow("user3", "hash3", typeof(Administrator))]
        [DataTestMethod]
        public void GetAll_AfterAddingUser_ShouldContainCorrectUserType(
            string username, string lozinka, Type expectedType)
        {
            // Arrange
            Korisnik korisnik = expectedType == typeof(Administrator) 
                ? new Administrator() 
                : new Gledalac();
            korisnik.setKorisnickoIme(username);
            korisnik.setLozinka(lozinka);
            repository.GetAll().Add(korisnik);

            // Act
            var result = repository.GetAll();

            // Assert
            Assert.IsTrue(result.Any(u => u.getKorisnickoIme() == username));
            var foundUser = result.First(u => u.getKorisnickoIme() == username);
            Assert.IsInstanceOfType(foundUser, expectedType);
            Assert.AreEqual(lozinka, foundUser.getLozinka());
        }

        [TestMethod]
        public void GetAll_AfterModification_ShouldReflectChanges()
        {
            // Arrange
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("original");
            repository.GetAll().Add(gledalac);

            // Act
            gledalac.setKorisnickoIme("modified");
            var result = repository.GetAll();

            // Assert
            Assert.AreEqual("modified", result[0].getKorisnickoIme());
        }

        [TestMethod]
        public void Sacuvaj_EmptyList_ShouldHandleGracefully()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act & Assert
            try
            {
                repository.Sacuvaj();
                Assert.IsTrue(true, "Sacuvaj treba da radi sa praznom listom");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Sacuvaj ne bi trebao baciti izuzetak sa praznom listom: {ex.Message}");
            }
        }

        [TestMethod]
        public void GetAll_MixedUserTypes_ShouldReturnAllUsers()
        {
            // Arrange
            var admin = new Administrator();
            admin.setKorisnickoIme("admin");
            admin.setLozinka("adminhash");

            var gledalac1 = new Gledalac();
            gledalac1.setKorisnickoIme("gledalac1");
            gledalac1.setLozinka("hash1");

            var gledalac2 = new Gledalac();
            gledalac2.setKorisnickoIme("gledalac2");
            gledalac2.setLozinka("hash2");

            repository.GetAll().Add(admin);
            repository.GetAll().Add(gledalac1);
            repository.GetAll().Add(gledalac2);

            // Act
            var result = repository.GetAll();

            // Assert
            Assert.AreEqual(3, result.Count);
            Assert.AreEqual(1, result.Count(u => u is Administrator));
            Assert.AreEqual(2, result.Count(u => u is Gledalac));
        }
    }
}
