namespace TestProject1.TestData
{
    public class UserServiceTestData
    {
        public string KorisnickoIme { get; set; }
        public string Lozinka { get; set; }
        public string TipKorisnika { get; set; }
        public bool OcekivaniUspeh { get; set; }
    }
}

