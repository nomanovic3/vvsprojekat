﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1.TestData
{
    public class FilmTestData 
    {
        public string PocetniNaziv { get; set; }
        public string NoviNaziv { get; set; }
        public string NovaKategorija { get; set; }
        public int NovaGodina { get; set; }
        public string OcekivaniToString { get; set; } // Očekivani formatirani string
    }
}
