namespace TestProject1.TestData
{
    public class FilmServiceTestData
    {
        public string Naziv { get; set; }
        public string Kategorija { get; set; }
        public double Ocjena { get; set; }
        public int Godina { get; set; }
        public int OcekivaniBrojFilmova { get; set; }
    }
}

