﻿using FilmMate.Data;
using FilmMate.Models;
using FilmMate.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace TestProject1.Models
{
    [TestClass]
    public class AdministratorTests
    {
        private TextReader _originalInput;
        private TextWriter _originalOutput;

        [TestInitialize]
        public void Setup()
        {
            // Sačuvaj originalne Console streams
            _originalInput = Console.In;
            _originalOutput = Console.Out;
        }

        [TestCleanup]
        public void Cleanup()
        {
            // Vrati originalne Console streams nakon svakog testa
            Console.SetIn(_originalInput);
            Console.SetOut(_originalOutput);
        }

        [TestMethod]
        public void Constructor_Default_ShouldCreateAdministrator()
        {
            // Arrange & Act
            var admin = new Administrator();

            // Assert
            Assert.IsNotNull(admin);
            Assert.IsInstanceOfType(admin, typeof(Administrator));
            Assert.IsInstanceOfType(admin, typeof(Korisnik));
        }

        [TestMethod]
        public void DodajFilm_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var admin = new Administrator();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Mock Console input - simulira unos: naziv, kategorija, ocjena, godina
            var input = new StringReader("Test Film\nAction\n8\n2023\n");
            Console.SetIn(input);

            // Mock Console output da ne zagađuje test output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            try
            {
                admin.dodajFilm(filmService);
                Assert.IsTrue(true, "Metoda je uspješno pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void ObrisiFilm_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var admin = new Administrator();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Mock Console input - simulira unos: naziv filma, potvrda 'n' (ne briši)
            var input = new StringReader("Test Film\nn\n");
            Console.SetIn(input);

            // Mock Console output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            try
            {
                admin.obrisiFilm(filmService);
                Assert.IsTrue(true, "Metoda je uspješno pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void AzurirajFilm_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var admin = new Administrator();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Mock Console input - simulira unos: naziv filma, izbor opcije
            var input = new StringReader("Test Film\n0\n");
            Console.SetIn(input);

            // Mock Console output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            try
            {
                admin.azurirajFilm(filmService);
                Assert.IsTrue(true, "Metoda je uspješno pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void DodajFilm_NullService_ShouldThrowException()
        {
            // Arrange
            var admin = new Administrator();

            // Mock Console input čak i za null test
            var input = new StringReader("Test\nAction\n5\n2023\n");
            Console.SetIn(input);
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => admin.dodajFilm(null));
        }

        [TestMethod]
        public void ObrisiFilm_NullService_ShouldThrowException()
        {
            // Arrange
            var admin = new Administrator();

            // Mock Console input čak i za null test
            var input = new StringReader("Test\nn\n");
            Console.SetIn(input);
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => admin.obrisiFilm(null));
        }

        [TestMethod]
        public void AzurirajFilm_NullService_ShouldThrowException()
        {
            // Arrange
            var admin = new Administrator();

            // Mock Console input čak i za null test
            var input = new StringReader("Test\n0\n");
            Console.SetIn(input);
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => admin.azurirajFilm(null));
        }

        [TestMethod]
        public void Administrator_InheritsFromKorisnik_ShouldHaveKorisnikMethods()
        {
            // Arrange
            var admin = new Administrator();

            // Act
            admin.setKorisnickoIme("admin");
            admin.setLozinka("adminhash");

            // Assert
            Assert.AreEqual("admin", admin.getKorisnickoIme());
            Assert.AreEqual("adminhash", admin.getLozinka());
        }
    }
}