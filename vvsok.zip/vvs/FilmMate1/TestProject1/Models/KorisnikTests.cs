﻿using FilmMate.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject1.Models
{
    [TestClass]
    public class KorisnikTests
    {
        // Koristimo Gledalac kao konkretnu implementaciju za testiranje apstraktne klase Korisnik
        private class TestKorisnik : Korisnik { }

        [TestMethod]
        public void SetKorisnickoIme_ValidInput_ShouldSetCorrectly()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            korisnik.setKorisnickoIme("testuser");

            // Assert
            Assert.AreEqual("testuser", korisnik.getKorisnickoIme());
        }

        [TestMethod]
        public void GetKorisnickoIme_AfterSetting_ShouldReturnCorrectValue()
        {
            // Arrange
            var korisnik = new Gledalac();
            string ocekivanoIme = "username123";

            // Act
            korisnik.setKorisnickoIme(ocekivanoIme);
            string rezultat = korisnik.getKorisnickoIme();

            // Assert
            Assert.AreEqual(ocekivanoIme, rezultat);
        }

        // Data Driven Test: Testiranje različitih korisničkih imena
        [DataRow("user1")]
        [DataRow("admin")]
        [DataRow("test_user")]
        [DataRow("korisnik123")]
        [DataRow("")]
        [DataTestMethod]
        public void SetKorisnickoIme_VariousInputs_ShouldSetCorrectly(string korisnickoIme)
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            korisnik.setKorisnickoIme(korisnickoIme);

            // Assert
            Assert.AreEqual(korisnickoIme, korisnik.getKorisnickoIme());
        }

        [TestMethod]
        public void SetLozinka_ValidInput_ShouldSetCorrectly()
        {
            // Arrange
            var korisnik = new Gledalac();
            string lozinka = "hashedpassword123";

            // Act
            korisnik.setLozinka(lozinka);

            // Assert
            Assert.AreEqual(lozinka, korisnik.getLozinka());
        }

        [TestMethod]
        public void GetLozinka_AfterSetting_ShouldReturnCorrectValue()
        {
            // Arrange
            var korisnik = new Gledalac();
            string ocekivanaLozinka = "hashedpass456";

            // Act
            korisnik.setLozinka(ocekivanaLozinka);
            string rezultat = korisnik.getLozinka();

            // Assert
            Assert.AreEqual(ocekivanaLozinka, rezultat);
        }

        [TestMethod]
        public void SetLozinka_EmptyString_ShouldSetCorrectly()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            korisnik.setLozinka("");

            // Assert
            Assert.AreEqual("", korisnik.getLozinka());
        }

        [TestMethod]
        public void SetKorisnickoIme_NullInput_ShouldHandleGracefully()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            korisnik.setKorisnickoIme(null);

            // Assert
            Assert.IsNull(korisnik.getKorisnickoIme());
        }

        [TestMethod]
        public void SetLozinka_NullInput_ShouldHandleGracefully()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            korisnik.setLozinka(null);

            // Assert
            Assert.IsNull(korisnik.getLozinka());
        }

        [TestMethod]
        public void GetKorisnickoIme_DefaultValue_ShouldReturnNull()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            string rezultat = korisnik.getKorisnickoIme();

            // Assert
            Assert.IsNull(rezultat);
        }

        [TestMethod]
        public void GetLozinka_DefaultValue_ShouldReturnNull()
        {
            // Arrange
            var korisnik = new Gledalac();

            // Act
            string rezultat = korisnik.getLozinka();

            // Assert
            Assert.IsNull(rezultat);
        }
    }
}
