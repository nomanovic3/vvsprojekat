﻿using FilmMate.Data;
using FilmMate.Models;
using FilmMate.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject1.Models
{
    [TestClass]
    public class GostTests
    {
        [TestMethod]
        public void Constructor_Default_ShouldCreateGost()
        {
            // Arrange & Act
            var gost = new Gost();

            // Assert
            Assert.IsNotNull(gost);
            Assert.IsInstanceOfType(gost, typeof(Gost));
        }

        [TestMethod]
        public void PregledajFilmove_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var gost = new Gost();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Act & Assert - ne bi trebalo baciti izuzetak
            try
            {
                gost.pregledajFilmove(filmService);
                Assert.IsTrue(true, "Metoda je pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void PregledajFilmove_NullService_ShouldThrowException()
        {
            // Arrange
            var gost = new Gost();

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => gost.pregledajFilmove(null));
        }

        [TestMethod]
        public void Gost_IsNotKorisnik_ShouldNotInheritFromKorisnik()
        {
            // Arrange
            var gost = new Gost();

            // Act & Assert
            Assert.IsNotInstanceOfType(gost, typeof(Korisnik));
        }
    }
}
