﻿using FilmMate.Data;
using FilmMate.Models;
using FilmMate.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace TestProject1.Models
{
    [TestClass]
    public class GledalacTests
    {
        [TestMethod]
        public void Constructor_Default_ShouldCreateGledalac()
        {
            // Arrange & Act
            var gledalac = new Gledalac();

            // Assert
            Assert.IsNotNull(gledalac);
            Assert.IsInstanceOfType(gledalac, typeof(Gledalac));
            Assert.IsInstanceOfType(gledalac, typeof(Korisnik));
        }

        [TestMethod]
        public void PregledajFilmove_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var gledalac = new Gledalac();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Mock Console output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            try
            {
                gledalac.pregledajFilmove(filmService);
                Assert.IsTrue(true, "Metoda je uspješno pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
            finally
            {
                // Vrati standardni output
                var standardOutput = new StreamWriter(Console.OpenStandardOutput()) { AutoFlush = true };
                Console.SetOut(standardOutput);
            }
        }

        [TestMethod]
        public void PretragaFilmova_WithFilmService_ShouldCallServiceMethod()
        {
            // Arrange
            var gledalac = new Gledalac();
            var repository = new FilmRepository();
            var filmService = new FilmService(repository);

            // Mock Console input - simulira odabir opcije '0' (povratak)
            var input = new StringReader("0\n");
            Console.SetIn(input);

            // Mock Console output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act & Assert
            try
            {
                gledalac.pretragaFilmova(filmService);
                Assert.IsTrue(true, "Metoda je uspješno pozvana");
            }
            catch (Exception ex) when (!(ex is NullReferenceException))
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
            finally
            {
                // Vrati standardni input/output
                var standardInput = new StreamReader(Console.OpenStandardInput());
                Console.SetIn(standardInput);
                var standardOutput = new StreamWriter(Console.OpenStandardOutput()) { AutoFlush = true };
                Console.SetOut(standardOutput);
            }
        }

        [TestMethod]
        public void PregledajFilmove_NullService_ShouldThrowException()
        {
            // Arrange
            var gledalac = new Gledalac();

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => gledalac.pregledajFilmove(null));
        }

        [TestMethod]
        public void PretragaFilmova_NullService_ShouldThrowException()
        {
            // Arrange
            var gledalac = new Gledalac();

            // Act & Assert
            Assert.ThrowsException<NullReferenceException>(() => gledalac.pretragaFilmova(null));
        }

        [TestMethod]
        public void Gledalac_InheritsFromKorisnik_ShouldHaveKorisnikMethods()
        {
            // Arrange
            var gledalac = new Gledalac();

            // Act
            gledalac.setKorisnickoIme("gledalac1");
            gledalac.setLozinka("hash123");

            // Assert
            Assert.AreEqual("gledalac1", gledalac.getKorisnickoIme());
            Assert.AreEqual("hash123", gledalac.getLozinka());
        }

        // Data Driven Test: Testiranje različitih korisničkih imena za gledaoca
        [DataRow("gledalac1")]
        [DataRow("user123")]
        [DataRow("test_gledalac")]
        [DataTestMethod]
        public void SetKorisnickoIme_VariousInputs_ShouldSetCorrectly(string korisnickoIme)
        {
            // Arrange
            var gledalac = new Gledalac();

            // Act
            gledalac.setKorisnickoIme(korisnickoIme);

            // Assert
            Assert.AreEqual(korisnickoIme, gledalac.getKorisnickoIme());
        }
    }
}