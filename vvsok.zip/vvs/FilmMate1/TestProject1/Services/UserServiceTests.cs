﻿using FilmMate.Data;
using FilmMate.Models;
using FilmMate.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using TestProject1.TestData;

namespace TestProject1.Services
{
    [TestClass]
    public class UserServiceTests
    {
        private UserRepository repository;
        private UserService userService;

        [TestInitialize]
        public void Setup()
        {
            repository = new UserRepository();
            repository.GetAll().Clear(); // Očistimo listu za testove
            userService = new UserService(repository);
        }

        [TestMethod]
        public void Constructor_WithRepository_ShouldInitializeCorrectly()
        {
            // Arrange & Act
            var service = new UserService(repository);

            // Assert
            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void Prijava_NonExistentUser_ShouldReturnNull()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act - Pošto Prijava koristi Console.ReadLine, testiramo samo da metoda postoji
            // Napomena: Za potpun test trebalo bi refaktorisati da ne koristi Console direktno
            
            // Assert - provjera da lista je prazna
            Assert.AreEqual(0, repository.GetAll().Count);
        }

        [TestMethod]
        public void Prijava_ValidCredentials_ShouldReturnUser()
        {
            // Arrange
            repository.GetAll().Clear();
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("testuser");
            string lozinka = "password123";
            string hash = GenerisiHash(lozinka);
            gledalac.setLozinka(hash);
            repository.GetAll().Add(gledalac);

            // Act - Pošto Prijava koristi Console.ReadLine, testiramo logiku kroz repository
            // Napomena: Za potpun test trebalo bi refaktorisati da ne koristi Console direktno
            
            // Assert - provjera da korisnik postoji
            Assert.IsTrue(repository.GetAll().Any(k => k.getKorisnickoIme() == "testuser"));
        }

        // Data Driven Test: Testiranje hash generisanja
        [DataRow("password123", "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f")]
        [DataRow("admin", "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918")]
        [DataRow("test", "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08")]
        [DataTestMethod]
        public void GenerisiHash_VariousPasswords_ShouldGenerateConsistentHash(string lozinka, string expectedHash)
        {
            // Arrange & Act
            string hash = GenerisiHash(lozinka);

            // Assert
            Assert.AreEqual(expectedHash, hash, $"Hash za '{lozinka}' nije ispravan");
        }

        [TestMethod]
        public void GenerisiHash_EmptyPassword_ShouldGenerateHash()
        {
            // Arrange
            string lozinka = "";

            // Act
            string hash = GenerisiHash(lozinka);

            // Assert
            Assert.IsNotNull(hash);
            Assert.IsTrue(hash.Length > 0);
        }

        [TestMethod]
        public void GenerisiHash_SamePassword_ShouldGenerateSameHash()
        {
            // Arrange
            string lozinka = "testpassword";

            // Act
            string hash1 = GenerisiHash(lozinka);
            string hash2 = GenerisiHash(lozinka);

            // Assert
            Assert.AreEqual(hash1, hash2, "Ista lozinka treba generisati isti hash");
        }

        // Data Driven Test: Testiranje različitih korisnika iz CSV-a
        [TestMethod]
        [DynamicData(nameof(GetUserServiceTestData), DynamicDataSourceType.Method)]
        public void UserService_WithCsvData_ShouldHandleCorrectly(UserServiceTestData testData)
        {
            // Arrange
            repository.GetAll().Clear();
            Korisnik korisnik = testData.TipKorisnika == "Administrator" 
                ? new Administrator() 
                : new Gledalac();
            korisnik.setKorisnickoIme(testData.KorisnickoIme);
            string hash = GenerisiHash(testData.Lozinka);
            korisnik.setLozinka(hash);
            repository.GetAll().Add(korisnik);

            // Act & Assert
            Assert.AreEqual(testData.OcekivaniUspeh, repository.GetAll().Count > 0);
            Assert.AreEqual(testData.KorisnickoIme, repository.GetAll()[0].getKorisnickoIme());
        }

        public static IEnumerable<object[]> GetUserServiceTestData()
        {
            return CsvDataLoader.GetTestData<UserServiceTestData>("TestData/UserServiceTestData.csv");
        }

        [TestMethod]
        public void Prijava_WrongPassword_ShouldReturnNull()
        {
            // Arrange
            repository.GetAll().Clear();
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("testuser");
            gledalac.setLozinka(GenerisiHash("correctpassword"));
            repository.GetAll().Add(gledalac);

            // Act - simulacija pogrešne lozinke
            // Pošto metoda koristi Console.ReadLine, testiramo logiku kroz repository
            
            // Assert - provjera da korisnik postoji ali sa drugom lozinkom
            var korisnik = repository.GetAll().FirstOrDefault(k => k.getKorisnickoIme() == "testuser");
            Assert.IsNotNull(korisnik);
            Assert.AreNotEqual(GenerisiHash("wrongpassword"), korisnik.getLozinka());
        }

        [TestMethod]
        public void Prijava_CaseSensitiveUsername_ShouldHandleCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            var gledalac = new Gledalac();
            gledalac.setKorisnickoIme("TestUser");
            gledalac.setLozinka(GenerisiHash("password"));
            repository.GetAll().Add(gledalac);

            // Act & Assert
            var korisnik = repository.GetAll().FirstOrDefault(k => k.getKorisnickoIme() == "TestUser");
            Assert.IsNotNull(korisnik);
            Assert.IsNull(repository.GetAll().FirstOrDefault(k => k.getKorisnickoIme() == "testuser"));
        }

        private string GenerisiHash(string lozinka)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(lozinka));
            var sb = new StringBuilder();
            foreach (var b in bytes) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }
}
