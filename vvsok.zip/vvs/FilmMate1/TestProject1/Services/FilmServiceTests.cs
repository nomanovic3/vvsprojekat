﻿using FilmMate.Data;
using FilmMate.Models;
using FilmMate.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using TestProject1.TestData;

namespace TestProject1.Services
{
    [TestClass]
    public class FilmServiceTests
    {
        private FilmRepository repository;
        private FilmService filmService;

        [TestInitialize]
        public void Setup()
        {
            repository = new FilmRepository();
            repository.GetAll().Clear(); // Očistimo listu za testove
            filmService = new FilmService(repository);
        }

        [TestMethod]
        public void Constructor_WithRepository_ShouldInitializeCorrectly()
        {
            // Arrange & Act
            var service = new FilmService(repository);

            // Assert
            Assert.IsNotNull(service);
        }

        [TestMethod]
        public void PrikaziJedinstveneKategorije_EmptyList_ShouldHandleGracefully()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act & Assert - ne bi trebalo baciti izuzetak
            try
            {
                filmService.PrikaziJedinstveneKategorije();
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void PrikaziJedinstveneKategorije_WithFilms_ShouldReturnUniqueCategories()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Film1", "Action", 8.0, 2020));
            repository.GetAll().Add(new Film("Film2", "Drama", 7.0, 2021));
            repository.GetAll().Add(new Film("Film3", "Action", 9.0, 2022));

            // Act
            filmService.PrikaziJedinstveneKategorije();

            // Assert - provjera da metoda radi bez greške
            Assert.IsTrue(true);
        }

        // Data Driven Test: Testiranje sortiranja po ocjeni
        [DataRow(true, new double[] { 5.0, 7.0, 9.0 })]
        [DataRow(false, new double[] { 9.0, 7.0, 5.0 })]
        [DataTestMethod]
        public void SortirajPoOcjeni_VariousRatings_ShouldSortCorrectly(bool rastuce, double[] ocekivaneOcjene)
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Film1", "Action", 7.0, 2020));
            repository.GetAll().Add(new Film("Film2", "Drama", 5.0, 2021));
            repository.GetAll().Add(new Film("Film3", "Comedy", 9.0, 2022));

            // Act
            filmService.SortirajPoOcjeni(rastuce);

            // Assert - provjera da je sortirano
            var sortiraneOcjene = repository.GetAll().Select(f => f.getOcjena()).ToArray();
            for (int i = 0; i < ocekivaneOcjene.Length; i++)
            {
                Assert.AreEqual(ocekivaneOcjene[i], sortiraneOcjene[i], 0.1, 
                    $"Sortiranje nije ispravno na poziciji {i}");
            }
        }

        [TestMethod]
        public void SortirajPoGodini_Rastuce_ShouldSortCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Film1", "Action", 8.0, 2022));
            repository.GetAll().Add(new Film("Film2", "Drama", 7.0, 2020));
            repository.GetAll().Add(new Film("Film3", "Comedy", 9.0, 2021));

            // Act
            filmService.SortirajPoGodini(true);

            // Assert
            Assert.AreEqual(2020, repository.GetAll()[0].getGodina());
            Assert.AreEqual(2021, repository.GetAll()[1].getGodina());
            Assert.AreEqual(2022, repository.GetAll()[2].getGodina());
        }

        [TestMethod]
        public void SortirajPoGodini_Opadajuce_ShouldSortCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Film1", "Action", 8.0, 2020));
            repository.GetAll().Add(new Film("Film2", "Drama", 7.0, 2022));
            repository.GetAll().Add(new Film("Film3", "Comedy", 9.0, 2021));

            // Act
            filmService.SortirajPoGodini(false);

            // Assert
            Assert.AreEqual(2022, repository.GetAll()[0].getGodina());
            Assert.AreEqual(2021, repository.GetAll()[1].getGodina());
            Assert.AreEqual(2020, repository.GetAll()[2].getGodina());
        }

        [TestMethod]
        public void SortirajPoNazivu_Rastuce_ShouldSortCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Zebra", "Action", 8.0, 2020));
            repository.GetAll().Add(new Film("Alpha", "Drama", 7.0, 2021));
            repository.GetAll().Add(new Film("Beta", "Comedy", 9.0, 2022));

            // Act
            filmService.SortirajPoNazivu(true);

            // Assert
            Assert.AreEqual("Alpha", repository.GetAll()[0].getNazivFilma());
            Assert.AreEqual("Beta", repository.GetAll()[1].getNazivFilma());
            Assert.AreEqual("Zebra", repository.GetAll()[2].getNazivFilma());
        }

        [TestMethod]
        public void SortirajPoNazivu_Opadajuce_ShouldSortCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Alpha", "Action", 8.0, 2020));
            repository.GetAll().Add(new Film("Zebra", "Drama", 7.0, 2021));
            repository.GetAll().Add(new Film("Beta", "Comedy", 9.0, 2022));

            // Act
            filmService.SortirajPoNazivu(false);

            // Assert
            Assert.AreEqual("Zebra", repository.GetAll()[0].getNazivFilma());
            Assert.AreEqual("Beta", repository.GetAll()[1].getNazivFilma());
            Assert.AreEqual("Alpha", repository.GetAll()[2].getNazivFilma());
        }

        [TestMethod]
        public void PrikaziFilmove_EmptyList_ShouldHandleGracefully()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act & Assert
            try
            {
                filmService.prikaziFilmove();
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void PrikaziFilmove_WithFilms_ShouldDisplayAll()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Film1", "Action", 8.0, 2020));
            repository.GetAll().Add(new Film("Film2", "Drama", 7.0, 2021));

            // Act
            filmService.prikaziFilmove();

            // Assert - provjera da metoda radi bez greške
            Assert.IsTrue(true);
        }

        // Data Driven Test: Testiranje različitih filmova iz CSV-a
        [TestMethod]
        [DynamicData(nameof(GetFilmServiceTestData), DynamicDataSourceType.Method)]
        public void PrikaziFilmove_WithCsvData_ShouldHandleCorrectly(FilmServiceTestData testData)
        {
            // Arrange
            repository.GetAll().Clear();
            var film = new Film(testData.Naziv, testData.Kategorija, testData.Ocjena, testData.Godina);
            repository.GetAll().Add(film);

            // Act
            filmService.prikaziFilmove();

            // Assert
            Assert.AreEqual(testData.OcekivaniBrojFilmova, repository.GetAll().Count);
            Assert.AreEqual(testData.Naziv, repository.GetAll()[0].getNazivFilma());
        }

        public static IEnumerable<object[]> GetFilmServiceTestData()
        {
            return CsvDataLoader.GetTestData<FilmServiceTestData>("TestData/FilmServiceTestData.csv");
        }

        [TestMethod]
        public void SortirajPoOcjeni_EmptyList_ShouldHandleGracefully()
        {
            // Arrange
            repository.GetAll().Clear();

            // Act & Assert
            try
            {
                filmService.SortirajPoOcjeni(true);
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Metoda ne bi trebala baciti izuzetak: {ex.Message}");
            }
        }

        [TestMethod]
        public void SortirajPoOcjeni_SingleFilm_ShouldHandleCorrectly()
        {
            // Arrange
            repository.GetAll().Clear();
            repository.GetAll().Add(new Film("Single", "Action", 8.0, 2020));

            // Act
            filmService.SortirajPoOcjeni(true);

            // Assert
            Assert.AreEqual(1, repository.GetAll().Count);
            Assert.AreEqual("Single", repository.GetAll()[0].getNazivFilma());
        }
    }
}
